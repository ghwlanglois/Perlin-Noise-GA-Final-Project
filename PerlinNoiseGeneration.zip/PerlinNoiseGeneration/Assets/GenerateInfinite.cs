﻿using UnityEngine;
using System.Collections;

class Tile
{
    public GameObject _tile;
    public float _creation_time;

    public Tile(GameObject _t, float _c_time)
    {
        _tile = _t;
        _creation_time = _c_time;
    }
}


public class GenerateInfinite : MonoBehaviour {

    public GameObject _plane;
    public GameObject _player;

    int _plane_size = 10;
    int _half_tiles_x = 5;
    int _half_tiles_z = 5;

    Vector3 _start_position;

    Hashtable _tiles = new Hashtable();

	// Use this for initialization
	void Start()
    {
        
        this.gameObject.transform.position = Vector3.zero;
        _start_position = Vector3.zero;

        float _update_time = Time.realtimeSinceStartup;
        
        for(int _x = -_half_tiles_x; _x < _half_tiles_x; _x++)
        {
            for (int _z = -_half_tiles_z; _z < _half_tiles_z; _z++)
            {
                Vector3 _position = new Vector3(
                                                (_x * _plane_size + _start_position.x),
                                                0,
                                                (_z * _plane_size + _start_position.z)
                                                );
                GameObject _t = (GameObject)Instantiate(_plane, _position, Quaternion.identity);

                string _tile_name = "Tile_" + ((int)(_position.x)).ToString() + "_" + ((int)(_position.z)).ToString();
                _t.name = _tile_name;
                Tile _tile = new Tile(_t, _update_time);
                _tiles.Add(_tile_name, _tile);
            }
        }
	}
	
	// Update is called once per frame
	void Update()
    {
        int _x_move = (int)(_player.transform.position.x - _start_position.x);
        int _z_move = (int)(_player.transform.position.z - _start_position.z);

        if (Mathf.Abs(_x_move) >= _plane_size || Mathf.Abs(_z_move) >= _plane_size)
        {
            float _update_time = Time.realtimeSinceStartup;

            int _player_x = (int)(Mathf.Floor(_player.transform.position.x / _plane_size) * _plane_size);
            int _player_z = (int)(Mathf.Floor(_player.transform.position.z / _plane_size) * _plane_size);

            for (int _x = -_half_tiles_x; _x < _half_tiles_x; _x++)
            {
                for (int _z = -_half_tiles_z; _z < _half_tiles_z; _z++)
                {
                    Vector3 _position = new Vector3(
                                                    (_x * _plane_size + _player_x),
                                                    0,
                                                    (_z * _plane_size + _player_z)
                                                    );

                    string _tile_name = "Tile_" + ((int)(_position.x)).ToString() + "_" + ((int)(_position.z)).ToString();

                    if (!_tiles.ContainsKey(_tile_name))
                    {
                        GameObject _t = (GameObject)Instantiate(_plane, _position, Quaternion.identity);
                        _t.name = _tile_name;
                        Tile _tile = new Tile(_t, _update_time);
                        _tiles.Add(_tile_name, _tile);
                    }
                    else
                    {
                        (_tiles[_tile_name] as Tile)._creation_time = _update_time;
                    }
                }
            }

            Hashtable _new_terrain = new Hashtable();
            foreach (Tile _tls in _tiles.Values)
            {
                if (_tls._creation_time != _update_time)
                {
                    Destroy(_tls._tile);
                }
                else
                {
                    _new_terrain.Add(_tls._tile.name, _tls);
                }
            }

            _tiles = _new_terrain;

            _start_position = _player.transform.position;
        }
    }
}
